import Viewer from './js/viewer';

export default Viewer;
